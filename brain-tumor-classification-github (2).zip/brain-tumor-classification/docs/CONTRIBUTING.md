# Contributing Guide

Thank you for considering contributing to this project!

## How to Contribute

1. **Fork** the repository
2. **Create a branch**: `git checkout -b feature/your-feature`
3. **Make changes** and add tests where applicable
4. **Run tests**: `pytest tests/ -v`
5. **Commit**: `git commit -m "feat: describe your change"`
6. **Push**: `git push origin feature/your-feature`
7. **Open a Pull Request** against `main`

## Commit Message Convention

| Prefix | Use |
|---|---|
| `feat:` | New feature |
| `fix:` | Bug fix |
| `docs:` | Documentation only |
| `test:` | Adding tests |
| `refactor:` | Code restructure |
| `chore:` | Maintenance |

## Code Style

- Follow PEP 8
- Add docstrings to all public functions
- Keep functions focused and small
