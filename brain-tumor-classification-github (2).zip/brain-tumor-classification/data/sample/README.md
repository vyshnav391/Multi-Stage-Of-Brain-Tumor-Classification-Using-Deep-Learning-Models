# Sample Data

Place sample MRI images here for quick testing.

**Do not commit** large datasets to this repository.  
Use [Git LFS](https://git-lfs.com) or download from [Kaggle](https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset).
