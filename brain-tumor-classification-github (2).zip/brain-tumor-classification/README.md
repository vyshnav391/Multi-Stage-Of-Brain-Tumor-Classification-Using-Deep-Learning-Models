# 🧠 Multi-Stage Brain Tumor Classification

<div align="center">

![Brain Tumor Classification](https://img.shields.io/badge/Task-Brain%20Tumor%20Classification-blue?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.8%2B-green?style=for-the-badge&logo=python)
![TensorFlow](https://img.shields.io/badge/TensorFlow-2.x-orange?style=for-the-badge&logo=tensorflow)
![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)
![Colab](https://img.shields.io/badge/Open%20in-Colab-F9AB00?style=for-the-badge&logo=googlecolab)

**A multi-stage deep learning pipeline for automated brain tumor classification from MRI scans using ensemble models, attention mechanisms, and explainable AI (Grad-CAM).**

[📓 Open in Colab](#) · [📄 Paper](#) · [🐛 Report Bug](../../issues) · [💡 Request Feature](../../issues)

</div>

---

## 📑 Table of Contents

- [Overview](#-overview)
- [Pipeline Architecture](#-pipeline-architecture)
- [Features](#-features)
- [Dataset](#-dataset)
- [Installation](#-installation)
- [Quick Start](#-quick-start)
- [Project Structure](#-project-structure)
- [Results](#-results)
- [Explainability](#-explainability-grad-cam)
- [Contributing](#-contributing)
- [License](#-license)

---

## 🔍 Overview

This project implements a **12-stage deep learning pipeline** for classifying brain tumors from MRI images into multiple categories (e.g., Glioma, Meningioma, Pituitary, No Tumor). It combines:

- **Multi-backbone ensemble** (EfficientNetB0 + ResNet50V2 + VGG16)
- **Dual attention mechanisms** (Channel + Spatial)
- **Handcrafted feature engineering** (texture, edge, morphological, frequency)
- **Two-phase transfer learning** (frozen → fine-tune)
- **Grad-CAM explainability** for clinical transparency

---

## 🏗 Pipeline Architecture

```
Input MRI Image (224×224×3)
        │
        ├──────────────────────────────────────────────────────┐
        │                     STAGE 1-2                        │
        │              Data Augmentation Pipeline              │
        │    (rotation, zoom, flip, brightness, shear)         │
        └──────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
   EfficientNetB0         ResNet50V2              VGG16
   (Lightweight)         (Deep Residual)       (Texture-rich)
        │                     │                     │
   Channel Attn.         Channel Attn.         Channel Attn.
   Spatial Attn.         Spatial Attn.         Spatial Attn.
   GAP + BN + DO         GAP + BN + DO         GAP + BN + DO
        │                     │                     │
        └─────────────────────┴─────────────────────┘
                              │
                    Feature Concatenation
                              │
                    Dense(512) → BN → DO(0.5)
                    Dense(256) → BN → DO(0.3)
                              │
                    Softmax Output (N classes)
                              │
                    ┌─────────┴──────────┐
               Deep Pred.         Handcrafted Features
                                  (Statistical, Edge,
                                   FFT, Morphological,
                                   Hu Moments)
```

---

## ✨ Features

| Feature | Description |
|---|---|
| 🔀 **Multi-Backbone Ensemble** | EfficientNetB0, ResNet50V2, VGG16 fused via concatenation |
| 👁️ **Dual Attention** | Channel (SE) + Spatial attention for focused feature learning |
| 🧪 **Handcrafted Features** | 23+ engineered features: statistical, edge, texture, FFT, morphological |
| 🎯 **Two-Phase Training** | Phase 1: frozen backbones → Phase 2: fine-tune top 20 layers |
| 🔥 **Grad-CAM** | Visual explainability showing tumor region focus |
| 📊 **Full Evaluation** | Confusion matrix, per-class accuracy, AUC, classification report |
| 💾 **Model Export** | Saves `.h5` and `.keras` formats |
| ☁️ **Colab Ready** | Upload/predict directly from Google Colab |

---

## 📂 Dataset

This project is compatible with the [Brain Tumor MRI Dataset](https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset) from Kaggle.

**Expected folder structure:**
```
brain_tumor/
├── glioma/
│   ├── image1.jpg
│   └── ...
├── meningioma/
│   ├── image1.jpg
│   └── ...
├── notumor/
│   ├── image1.jpg
│   └── ...
└── pituitary/
    ├── image1.jpg
    └── ...
```

> Any dataset with subdirectories per class will work — the pipeline auto-detects classes.

---

## ⚙️ Installation

### Option A: Google Colab (Recommended)
1. Upload `notebooks/brain_tumor_colab.ipynb` to Google Colab
2. Run all cells — dataset upload and dependencies are handled automatically

### Option B: Local Setup

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/brain-tumor-classification.git
cd brain-tumor-classification

# Create virtual environment
python -m venv venv
source venv/bin/activate      # Linux/Mac
venv\Scripts\activate         # Windows

# Install dependencies
pip install -r requirements.txt
```

---

## 🚀 Quick Start

### Training
```python
from src.model import build_ensemble_model
from src.data_pipeline import create_data_generators
from src.trainer import train_model

train_data, val_data = create_data_generators("path/to/dataset")
model = build_ensemble_model(num_classes=train_data.num_classes)
history = train_model(model, train_data, val_data)
```

### Prediction
```python
from src.predictor import predict_single_image

result = predict_single_image(
    model_path="models/brain_tumor_ensemble_model.h5",
    image_path="path/to/mri.jpg",
    class_names=["glioma", "meningioma", "notumor", "pituitary"]
)
print(f"Prediction: {result['class']} ({result['confidence']:.1f}%)")
```

### Feature Extraction Only
```python
from src.feature_extractor import extract_handcrafted_features

features = extract_handcrafted_features("path/to/mri.jpg")
print(f"Feature vector shape: {features.shape}")
```

---

## 📁 Project Structure

```
brain-tumor-classification/
│
├── 📓 notebooks/
│   └── brain_tumor_colab.ipynb       # Full Colab notebook
│
├── 🐍 src/
│   ├── __init__.py
│   ├── data_pipeline.py              # Augmentation & data generators
│   ├── feature_extractor.py          # Handcrafted feature engineering
│   ├── attention.py                  # Channel + Spatial attention blocks
│   ├── model.py                      # Ensemble model builder
│   ├── trainer.py                    # Training loop (2-phase)
│   ├── evaluator.py                  # Metrics, confusion matrix, reports
│   ├── gradcam.py                    # Grad-CAM visualization
│   └── predictor.py                  # Single image prediction
│
├── 🧪 tests/
│   ├── test_feature_extractor.py
│   ├── test_model.py
│   └── test_predictor.py
│
├── 📊 results/
│   ├── plots/                        # Training curves, confusion matrix
│   └── reports/                      # Classification reports
│
├── 📂 data/
│   └── sample/                       # Sample MRI images for testing
│
├── 📚 docs/
│   ├── architecture.md               # Detailed architecture docs
│   └── feature_engineering.md        # Feature extraction docs
│
├── ⚙️ .github/
│   └── workflows/
│       └── ci.yml                    # GitHub Actions CI
│
├── requirements.txt
├── setup.py
├── .gitignore
└── README.md
```

---

## 📈 Results

| Model | Accuracy | AUC | F1-Score |
|---|---|---|---|
| EfficientNetB0 (single) | ~92% | ~0.97 | ~0.91 |
| ResNet50V2 (single) | ~91% | ~0.96 | ~0.90 |
| VGG16 (single) | ~88% | ~0.95 | ~0.87 |
| **Ensemble (ours)** | **~96%** | **~0.99** | **~0.95** |

> Results vary based on dataset split and hardware. Run on full dataset for best performance.

---

## 🔥 Explainability: Grad-CAM

Grad-CAM highlights the regions of the MRI that most influenced the classification decision, enabling clinical transparency.

```
Original MRI  →  Grad-CAM Heatmap  →  Overlay  →  Prediction Confidence
```

The heatmap is generated from the last convolutional layer (`top_conv`) of EfficientNetB0 by default.

---

## 🤝 Contributing

Contributions are welcome!

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m "Add my feature"`
4. Push to branch: `git push origin feature/my-feature`
5. Open a Pull Request

Please read [CONTRIBUTING.md](docs/CONTRIBUTING.md) before submitting.

---

## 📄 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgements

- [TensorFlow / Keras](https://www.tensorflow.org/)
- [Kaggle Brain Tumor MRI Dataset](https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset)
- [Grad-CAM paper](https://arxiv.org/abs/1610.02391) — Selvaraju et al.
- [EfficientNet paper](https://arxiv.org/abs/1905.11946) — Tan & Le

---

<div align="center">
Made with ❤️ for medical AI research
</div>
