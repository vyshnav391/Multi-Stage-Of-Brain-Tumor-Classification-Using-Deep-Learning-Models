"""
Tests for the handcrafted feature extractor.
"""

import numpy as np
import os
import tempfile
import pytest
import cv2

from src.feature_extractor import extract_handcrafted_features, FEATURE_NAMES


def _create_dummy_image(path: str, size: int = 128):
    img = np.random.randint(0, 256, (size, size, 3), dtype=np.uint8)
    cv2.imwrite(path, img)


class TestHandcraftedFeatures:

    def test_feature_vector_length(self, tmp_path):
        img_path = str(tmp_path / "test.jpg")
        _create_dummy_image(img_path)
        feats = extract_handcrafted_features(img_path)
        assert feats.shape == (len(FEATURE_NAMES),), \
            f"Expected {len(FEATURE_NAMES)} features, got {feats.shape[0]}"

    def test_feature_dtype(self, tmp_path):
        img_path = str(tmp_path / "test.jpg")
        _create_dummy_image(img_path)
        feats = extract_handcrafted_features(img_path)
        assert feats.dtype == np.float32

    def test_no_nan_features(self, tmp_path):
        img_path = str(tmp_path / "test.jpg")
        _create_dummy_image(img_path)
        feats = extract_handcrafted_features(img_path)
        assert not np.any(np.isnan(feats)), "Feature vector contains NaN values"

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            extract_handcrafted_features("/nonexistent/path/img.jpg")

    def test_feature_names_count(self):
        assert len(FEATURE_NAMES) == 23, \
            f"Expected 23 feature names, got {len(FEATURE_NAMES)}"
