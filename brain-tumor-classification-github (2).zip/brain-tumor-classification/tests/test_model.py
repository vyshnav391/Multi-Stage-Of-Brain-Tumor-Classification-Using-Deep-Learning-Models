"""
Tests for ensemble model construction.
"""

import numpy as np
import pytest
import tensorflow as tf

from src.model import build_ensemble_model


class TestEnsembleModel:

    def test_model_builds(self):
        model = build_ensemble_model(num_classes=4)
        assert isinstance(model, tf.keras.Model)

    def test_output_shape(self):
        num_classes = 4
        model = build_ensemble_model(num_classes=num_classes)
        dummy = np.zeros((2, 224, 224, 3), dtype=np.float32)
        out = model.predict(dummy, verbose=0)
        assert out.shape == (2, num_classes)

    def test_output_probabilities(self):
        model = build_ensemble_model(num_classes=4)
        dummy = np.random.rand(1, 224, 224, 3).astype(np.float32)
        out = model.predict(dummy, verbose=0)
        assert np.allclose(np.sum(out, axis=1), 1.0, atol=1e-5), \
            "Softmax outputs do not sum to 1"

    def test_model_name(self):
        model = build_ensemble_model(num_classes=3)
        assert "BrainTumor" in model.name
