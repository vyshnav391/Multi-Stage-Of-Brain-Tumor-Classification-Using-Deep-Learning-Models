#!/usr/bin/env bash
# =============================================================
# upload_to_github.sh
# One-shot script to initialize and push the project to GitHub
# =============================================================
# Usage:
#   chmod +x upload_to_github.sh
#   ./upload_to_github.sh YOUR_GITHUB_USERNAME REPO_NAME
# =============================================================

set -e   # Exit on any error

USERNAME=${1:-"YOUR_USERNAME"}
REPO=${2:-"brain-tumor-classification"}
BRANCH="main"

echo "=========================================="
echo " Brain Tumor Classification — GitHub Push"
echo "=========================================="
echo " Username : $USERNAME"
echo " Repo     : $REPO"
echo ""

# ── Step 1: Git init ──────────────────────────────────────────
if [ ! -d ".git" ]; then
  git init
  echo "✅ Git repository initialized"
else
  echo "ℹ️  Git already initialized"
fi

# ── Step 2: Create results dirs (empty, kept by .gitkeep) ─────
mkdir -p results/plots results/reports data/sample models
touch results/plots/.gitkeep
touch results/reports/.gitkeep
touch data/sample/.gitkeep
touch models/.gitkeep

# ── Step 3: Stage all files ───────────────────────────────────
git add .
echo "✅ Files staged"

# ── Step 4: Initial commit ────────────────────────────────────
git commit -m "feat: initial commit — multi-stage brain tumor classification

- Multi-backbone ensemble (EfficientNetB0 + ResNet50V2 + VGG16)
- CBAM attention (channel + spatial)
- 23-feature handcrafted feature extraction
- Two-phase transfer learning
- Grad-CAM explainability
- Full evaluation suite (confusion matrix, classification report)
- GitHub Actions CI workflow
- Unit tests"

echo "✅ Initial commit created"

# ── Step 5: Set branch and remote ────────────────────────────
git branch -M $BRANCH
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/$USERNAME/$REPO.git"
echo "✅ Remote set to: https://github.com/$USERNAME/$REPO.git"

# ── Step 6: Push ─────────────────────────────────────────────
echo ""
echo "🚀 Pushing to GitHub..."
echo "   (You may be prompted for your GitHub credentials)"
echo "   Tip: Use a Personal Access Token as your password"
echo ""
git push -u origin $BRANCH

echo ""
echo "✅ Successfully pushed!"
echo "🌐 View your repo at: https://github.com/$USERNAME/$REPO"
