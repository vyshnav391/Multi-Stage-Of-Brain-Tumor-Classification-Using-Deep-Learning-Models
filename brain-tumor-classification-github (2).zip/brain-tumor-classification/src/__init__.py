"""
Brain Tumor Classification — Multi-Stage Deep Learning Pipeline
"""
__version__ = "1.0.0"
